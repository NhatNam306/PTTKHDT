<?php
$mysqli = new mysqli("localhost","root","","test2");

// Check connection
if ($mysqli->connect_errno) {
  echo "Kết nối mySqli lỗi" . $mysqli->connect_error;
  exit();
}
?>