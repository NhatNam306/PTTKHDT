<?php
include("/f8/PHP/web/module/config/config.php");
// tao bien de Post value
$maHD = $_POST['Full_Contract_Code'];
$tenkhachhang = $_POST['Customer_Name'];
$namsinh = $_POST['Year_Of_Birth'];
$CMND = $_POST['SSN'];
$diachi = $_POST['Customer_Address'];
$SDT = $_POST['Mobile'];
$MaBDS = $_POST['Property_ID'];
$ngaylaphopdong = $_POST['Date_Of_Contract'];
$giatrihopdong = $_POST['Price'];
$sotiendacoc = $_POST['Deposit'];
$sotienconlai = $_POST['Remain'];
$trangthai = $_POST['Status'];
// Logic
if(isset($_POST['themhopdongbds'])) {
    $sql_them = "INSERT INTO full_contract(Full_Contract_Code, Customer_Name, Year_Of_Birth, SSN, Customer_Address, Mobile,Property_ID, Date_Of_Contract, Price, Deposit, Remain, Status) 
                VALUE('".$maHD."','".$tenkhachhang."', '".$namsinh."', '".$CMND."', '".$diachi."', '".$SDT."','".$MaBDS."', '".$ngaylaphopdong."', '".$giatrihopdong."', 
                '".$sotiendacoc."', '".$sotienconlai."', '".$trangthai."')";
    mysqli_query($mysqli, $sql_them);
    header('Location:/module/add_complete.php');
}
?>