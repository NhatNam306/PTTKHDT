<!-- List items -->
<div class="grid__column-8">
    <div class="home-manager">
        <div class="home-manager_title">
            <h2 class="home-manager__heading">Danh sách hợp đồng bất động sản</h2>
            <h4 class="home-manager__pagecount">Trang 1|100</h4>
        </div>
        <div class="input_search">
            <input type="search" name="" class="home-manager__search" placeholder=" Tìm kiếm bất động sản" />
            <div class="home-manager__search-btn">
                <span class="home-manager__search-btn-label">Tìm kiếm</span>
            </div>
        </div>
    </div>
    <?php
    $sql_lietke = "SELECT * FROM full_contract ORDER BY ID DESC";
    $row_lietke = mysqli_query($mysqli, $sql_lietke);
    ?>
    <div class="home-manager_product">
        <div class="list_proudct">
            <!-- STT -->
            <div class="list_product-count">
                <span>ID</span>
            </div>
            <!-- Code -->
            <div class="list_product-code">
                <span>Mã hợp đồng bất động sản</span>
            </div>
            <!-- Name -->
            <div class="list_product-name">
                <span>Họ tên người mua</span>
            </div>
            <!-- Address -->
            <div class="list_product-address">
                <span>Địa chỉ</span>
            </div>
            <!-- Tool -->
            <div class="list_product-tool">
                <span>Tác vụ</span>
            </div>
        </div>
        <?php
        $i = 0;
        while ($row = mysqli_fetch_array($row_lietke)) {
            $i++;
        ?>
        <div class="list_proudct">
            <!-- STT -->
            <div class="list_product-count">
                <?php
                    echo $i
                    ?>
            </div>
            <!-- Code -->
            <div class="list_product-code">
                <?php
                    echo $row['Full_Contract_Code']
                    ?>
            </div>
            <!-- Name -->
            <div class="list_product-name">
                <?php
                    echo $row['Customer_Name']
                    ?>
            </div>
            <!-- Address -->
            <div class="list_product-address">
                <?php
                    echo $row['Customer_Address']
                    ?>
            </div>
            <!-- Tool -->
            <div class="list_product-tool">
                <div class="list_product-tool--delete">
                    <a href="">Xóa</a>
                </div>
                <div class="list_product-tool--print">
                    <a href="">Sửa</a>
                </div>
            </div>
        </div>
        <?php
        }
        ?>
    </div>

</div>


</div>
</div>
<div class="next-page-btn">
    <button class="next-page">Trang kế tiếp</button>
</div>