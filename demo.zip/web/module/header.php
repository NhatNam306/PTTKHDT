<header class="header">
    <div class="grid">
        <nav class="header__navbar">
            <!-- Logo -->
            <div class="header__navbar-img">
                <img src="/asset/images/LOGO.png" alt="" class="header__navbar-logo" />
            </div>
            <!-- Title -->
            <a href="!" class="header__navbar-title">Perfect Property Company</a>
        </nav>
    </div>
</header>