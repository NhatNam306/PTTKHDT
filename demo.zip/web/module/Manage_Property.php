<!-- Manage Property -->
<div class="container">
    <div class="grid">
        <div class="grid__row">
            <?php 
                include("./col4/col4.php")
            ?>

            <?php include("./col8/col8.php") ?>


        </div>
    </div>
</div>