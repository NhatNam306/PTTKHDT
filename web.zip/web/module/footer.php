<div class="footer">
    <span>@Coppyright by team A.S.K</span>
</div>