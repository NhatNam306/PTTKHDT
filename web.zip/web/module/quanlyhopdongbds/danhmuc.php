<link rel="stylesheet" href="/web//css//style.css">
<div class="home-manager">
    <div class="home-manager_title">
        <h2 class="home-manager__heading">Danh sách hợp đồng bất động sản</h2>
        <h4 class="home-manager__pagecount">Trang 1|100</h4>
    </div>
    <div class="input_search">
        <input type="search" name="" class="home-manager__search" placeholder=" Tìm kiếm bất động sản" />
        <div class="home-manager__search-btn">
            <span class="home-manager__search-btn-label">Tìm kiếm</span>
        </div>
    </div>
</div>
<div class="home-manager_product">
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>STT</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>Mã hợp đồng bất động sản</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Họ tên người mua</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span>Địa chỉ</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <span>Tác vụ</span>
        </div>
    </div>
    <!-- List items -->
    <!-- 1 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 2 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!--3 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 4 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 5 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 6 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 7 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 8 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 9 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 10 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 11 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 12 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 13 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 14 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 15 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 16 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 17 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 18 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 19 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
    <!-- 20 -->
    <div class="list_proudct">
        <!-- STT -->
        <div class="list_product-count">
            <span>1</span>
        </div>
        <!-- Code -->
        <div class="list_product-code">
            <span>207CT40449</span>
        </div>
        <!-- Name -->
        <div class="list_product-name">
            <span>Huỳnh Nhật Nam</span>
        </div>
        <!-- Address -->
        <div class="list_product-address">
            <span> Đường Số 8, Phường Phú Mỹ, Quận 7, Hồ Chí Minh</span>
        </div>
        <!-- Tool -->
        <div class="list_product-tool">
            <div class="list_product-tool--delete">
                <a href="">Xóa</a>
            </div>
            <div class="list_product-tool--print">
                <a href="">Sửa</a>
            </div>
        </div>
    </div>
</div>
<div class="next-page-btn">
    <button class="next-page">Trang kế tiếp</button>
</div>