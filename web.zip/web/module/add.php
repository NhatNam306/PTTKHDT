<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Perfect Property Company</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
    <!-- Link CSS -->
    <!-- <link rel="stylesheet" href="./assets/css/reset.css" /> -->
    <link rel="stylesheet" href="/css/add.css" />
</head>

<body>
    <div class="main">
        <?php
            include("./header.php");
        ?>
        <!-- Manage Property -->
        <div class="container">
            <div class="grid">
                <div class="grid__row">
                    <div class="grid__column-4">
                        <nav class="category" style="margin-top: 16px">
                            <h3 class="category-heading">Quản lý bất động sản</h3>
                            <ul class="category-list">
                                <li class="category-items">
                                    <a href="#!" class="category-items-link ">
                                        Danh sách bất động sản
                                    </a>
                                </li>
                                <li class="category-items">
                                    <a href="#!" class="category-items-link">
                                        Thêm bất động sản
                                    </a>
                                </li>
                            </ul>
                        </nav>
                        <nav class="category" style="height: 81%">
                            <h3 class="category-heading">Quản lý hợp đồng bất động sản</h3>
                            <ul class="category-list">
                                <li class="category-items">
                                    <a href="/module/index.php" class="category-items-link ">
                                        Danh sách hợp đồng bất động sản
                                    </a>
                                </li>
                                <li class="category-items">
                                    <a href="/module/add.php" class="category-items-link category-items_link--active">
                                        Thêm hợp đồng bất động sản
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>

                    <div class="grid__column-8">
                        <form method="POST" action="/module/quanlyhopdongbds/xuly.php" class="home-manager">
                            <div class="home-manager_title">
                                <h2 class="home-manager__heading">Thêm hợp đồng bất động sản</h2>
                            </div>

                            <div class="home-manager_product">
                                <h3> Thông tin cơ bản</h3>

                                <div class="home-manager_product-inp">
                                    <label for="name">Mã Hợp Đồng Bất Động Sản <b style="color: red;">*</b> (Không
                                        chỉnh sửa)</label>
                                    <input type="text" name="Full_Contract_Code" id="name">

                                    <div class="home-manager_product-inp">
                                        <label for="name">Họ tên người mua <b style="color: red;">*</b></label>
                                        <input type="text" name="Customer_Name" id="name">
                                    </div>

                                    <div class="home-manager_product-inp">
                                        <label for="name">Sinh năm <b style="color: red;">*</b></label>
                                        <input type="int" name="Year_Of_Birth" id="name">
                                    </div>

                                    <div class="home-manager_product-inp">
                                        <label for="name">CMND<b style="color: red;">*</b></label>
                                        <input type="text" name="SSN" id="name">
                                    </div>

                                    <div class="home-manager_product-inp">
                                        <label for="name">Địa chỉ <b style="color: red;">*</b></label>
                                        <input type="text" name="Customer_Address" id="name">
                                    </div>

                                    <div class="home-manager_product-inp">
                                        <label for="name">Số điện thoại <b style="color: red;">*</b></label>
                                        <input type="tel" name="Mobile" id="name">
                                    </div>

                                    <div class="home-manager_product-inp">
                                        <label for="name">Mã Bất Động Sản <b style="color: red;">*</b></label>
                                        <input type="int" name="Property_ID" id="name">
                                    </div>

                                    <div class="home-manager_product-inp">
                                        <label for="name">Ngày lập hợp đồng <b style="color: red;">*</b></label>
                                        <input type="date" name="Date_Of_Contract" id="name">
                                    </div>

                                    <div class="home-manager_product-inp">
                                        <label for="name"><i class="fa-solid fa-coins"></i>Giá trị hợp đồng <b
                                                style="color: red;">*</b></label>
                                        <input type="text" name="Price" id="name">
                                    </div>

                                    <div class="home-manager_product-inp">
                                        <label for="name">Số tiền đã cọc <b style="color: red;">*</b></label>
                                        <input type="text" name="Deposit" id="name"
                                            placeholder="Giá trị = giá bán BĐS">
                                    </div>

                                    <div class="home-manager_product-inp">
                                        <label for="name">Số tiền còn lại <b style="color: red;">*</b></label>
                                        <input type="text" name="Remain" id="name"
                                            placeholder="Giá trị = giá bán BĐS">
                                    </div>

                                    <div class="home-manager_product-inp">
                                        <label for="name">Trạng thái <b style="color: red;">*</b></label>
                                        <select name="Status" id="">
                                            <option value="Đang bán">1</option>
                                            <option value="Đã bán thanh toán một lần">2</option>
                                            <option value="Đã bán trả góp">3</option>
                                            <option value="Không hiển thị">4</option>
                                            <option value="Hết hạn để bán">5</option>
                                            <option value="Đang cọc đầy đủ">6</option>
                                            <option value="Đang cọc trả góp">7</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="next-page-btn">
                                    <input style="margin-right: 5px;" type="submit" value="Hủy">
                                    <input class="" type="submit" value="Thêm" name="themhopdongbds">
                                </div>
                        </form>

                    </div>

                </div>

            </div>
        </div>
        <?php include("./footer.php"); ?>
</body>

</html>