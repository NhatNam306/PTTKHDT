<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Perfect Property Company</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.1/normalize.min.css" />
    <!-- Link CSS -->
    <!-- <link rel="stylesheet" href="./assets/css/reset.css" /> -->
    <link rel="stylesheet" href="/css/style.css" />
    <!-- <link rel="stylesheet" href="/web/css/add.css"> -->
</head>

<body>
    <div class="main">
        <?php
            include("./config/config.php");
            include("./header.php");
        ?>
        <div class="container">
            <div class="grid">
                <div class="grid__row">
                    <div class="grid__column-4">
                        <nav class="category" style="margin-top: 16px">
                            <h3 class="category-heading">Quản lý bất động sản</h3>
                            <ul class="category-list">
                                <li class="category-items">
                                    <a href="#!" class="category-items-link ">
                                        Danh sách bất động sản
                                    </a>
                                </li>
                                <li class="category-items">
                                    <a href="#!" class="category-items-link">
                                        Thêm bất động sản
                                    </a>
                                </li>
                            </ul>
                        </nav>
                        <nav class="category" style="height: 81%">
                            <h3 class="category-heading">Quản lý hợp đồng bất động sản</h3>
                            <ul class="category-list">
                                <li class="category-items">
                                    <a href="/module/index.php" class="category-items-link category-items_link--active">
                                        Danh sách hợp đồng bất động sản
                                    </a>
                                </li>
                                <li class="category-items">
                                    <a href="/module/add.php" class="category-items-link ">
                                        Thêm hợp đồng bất động sản
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </div>

                    <div class="grid__column-8">
                        <div class="home-manager">
                            <div class="home-manager_title">
                                <h2 class="home-manager__heading">Danh sách hợp đồng bất động sản</h2>
                                <h4 class="home-manager__pagecount">Trang 1|100</h4>
                            </div>
                            <div class="input_search">
                                <input type="search" name="" class="home-manager__search"
                                    placeholder=" Tìm kiếm bất động sản" />
                                <div class="home-manager__search-btn">
                                    <span class="home-manager__search-btn-label">Tìm kiếm</span>
                                </div>
                            </div>
                        </div>
                        <?php 
                            $sql_lietke = "SELECT * FROM full_contract ORDER BY ID DESC";
                            $row_lietke = mysqli_query($mysqli, $sql_lietke);
                        ?>
                        <div class="home-manager_product">
                            <div class="list_proudct">
                                <!-- STT -->
                                <div class="list_product-count">
                                    <span>ID</span>
                                </div>
                                <!-- Code -->
                                <div class="list_product-code">
                                    <span>Mã hợp đồng bất động sản</span>
                                </div>
                                <!-- Name -->
                                <div class="list_product-name">
                                    <span>Họ tên người mua</span>
                                </div>
                                <!-- Address -->
                                <div class="list_product-address">
                                    <span>Địa chỉ</span>
                                </div>
                                <!-- Tool -->
                                <div class="list_product-tool">
                                    <span>Tác vụ</span>
                                </div>
                            </div>
                            <?php
                                $i = 0;
                                while($row = mysqli_fetch_array($row_lietke)) {
                                    $i++;
                            ?>
                            <div class="list_proudct">
                                <!-- STT -->
                                <div class="list_product-count">
                                    <?php
                                        echo $i
                                    ?>
                                </div>
                                <!-- Code -->
                                <div class="list_product-code">
                                    <?php
                                        echo $row['Full_Contract_Code']
                                    ?>
                                </div>
                                <!-- Name -->
                                <div class="list_product-name">
                                    <?php
                                        echo $row['Customer_Name']
                                    ?>
                                </div>
                                <!-- Address -->
                                <div class="list_product-address">
                                    <?php
                                        echo $row['Customer_Address']
                                    ?>
                                </div>
                                <!-- Tool -->
                                <div class="list_product-tool">
                                    <div class="list_product-tool--delete">
                                        <a href="">Xóa</a>
                                    </div>
                                    <div class="list_product-tool--print">
                                        <a href="">Sửa</a>
                                    </div>
                                </div>
                            </div>
                            <?php
                                }
                            ?>
                        </div>

                    </div>
                </div>
                <?php
            include('/f8/PHP/web/module/footer.php')
        ?>
            </div>
</body>

</html>