<div class="grid__column-4">
    <nav class="category" style="margin-top: 16px">
        <h3 class="category-heading">Quản lý bất động sản</h3>
        <ul class="category-list">
            <li class="category-items">
                <a href="./index.php" class="category-items-link ">
                    Danh sách bất động sản
                </a>
            </li>
            <li class="category-items">
                <a href="#!" class="category-items-link">
                    Thêm bất động sản
                </a>
            </li>
        </ul>
    </nav>
    <nav class="category" style="height: 695px">
        <h3 class="category-heading">Quản lý hợp đồng bất động sản</h3>
        <ul class="category-list">
            <li class="category-items">
                <a href="/module/index.php" class="category-items-link category-items_link--active">
                    Danh sách hợp đồng bất động sản
                </a>
            </li>
            <li class="category-items">
                <a href="/module/add.php" class="category-items-link">
                    Thêm hợp đồng bất động sản
                </a>
            </li>
        </ul>
    </nav>
</div>